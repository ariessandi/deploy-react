# ReactJs - simple crud POKEMON APP
This is simple crud app with pokemon data on variable, understanding of react think . <br>

## Features
* CRUD (create, read, update, delete) 

## Used Technology
[reactJs](https://reactjs.org/) 

##clone this repo

##instal npm

##run on your local using npm start