import React, { Component } from 'react';
import './App.css';

class App extends Component {

  constructor(props){
    super(props);
    this.state={
      title: 'Pokemon Application',
      act: 0,
      index: '',
      datas: [
      {name:'pikacu',details:'Kuning Kekuatan Setrum',hp:10,attack:150,deffense:50,pokemonType:'electric'},
      {name:'raicu',details:'Evolusi dari pikacu',hp:10,attack:150,deffense:50,pokemonType:'electric'},
      {name:'bulbasaur',details:'pokemon air kuat',hp:10,attack:150,deffense:50,pokemonType:'water'},
      {name:'pidgetto',details:'pokemon burung bisa terbang',hp:10,attack:150,deffense:50,pokemonType:'bird'},
      {name:'squirtle',details:'pokemon air kura kura',hp:10,attack:150,deffense:50,pokemonType:'water'},
      {name:'charmender',details:'pokemon naga',hp:10,attack:150,deffense:50,pokemonType:'dragon'},
      {name:'ratatta',details:'pokemon tikus',hp:10,attack:150,deffense:50,pokemonType:'Tanah'},
      {name:'Meow',details:'pokemon kucing',hp:10,attack:150,deffense:50,pokemonType:'cat'},
      {name:'Mewtwo',details:'pokemon naga',hp:10,attack:150,deffense:50,pokemonType:'dragon'},
      {name:'jiggly puff',details:'pokemon kecil',hp:10,attack:150,deffense:50,pokemonType:'sing'},
      {name:'rock',details:'pokemon batu',hp:10,attack:150,deffense:50,pokemonType:'rock'},
      {name:'coffin',details:'pokemon bom',hp:10,attack:150,deffense:50,pokemonType:'bomb'},
      {name:'snake',details:'pokemon ular',hp:10,attack:150,deffense:50,pokemonType:'snake'},
      {name:'charizzard',details:'pokemon naga besar',hp:10,attack:150,deffense:50,pokemonType:'dragon'},
      {name:'star',details:'pokemon bintang laut',hp:10,attack:150,deffense:50,pokemonType:'water'}

      ]
    }
  } 

  componentDidMount(){
    this.refs.name.focus();
  }

  fSubmit = (e) =>{
    e.preventDefault();
    console.log('try');

    let datas = this.state.datas;
    let name = this.refs.name.value;
    let details = this.refs.details.value;
    let hp = this.refs.hp.value;
    let attack = this.refs.attack.value;
    let deffense = this.refs.deffense.value;
    let pokemonType = this.refs.pokemonType.value;

    if(this.state.act === 0){   //new
      let data = { name,details,hp,attack,deffense,pokemonType }
      datas.push(data);
    }else{                      //update
      let index = this.state.index;
      datas[index].name = name;
      datas[index].details = details;
      datas[index].hp = hp;
      datas[index].attack = attack;
      datas[index].deffense = deffense;
      datas[index].pokemonType = pokemonType;
    }    

    this.setState({
      datas: datas,
      act: 0
    });

    this.refs.myForm.reset();
    this.refs.name.focus();
  }

  fRemove = (i) => {
    let datas = this.state.datas;
    datas.splice(i,1);
    this.setState({
      datas: datas
    });

    this.refs.myForm.reset();
    this.refs.name.focus();
  }

  fEdit = (i) => {
    let data = this.state.datas[i];
    this.refs.name.value = data.name;
    this.refs.details.value = data.details;
    this.refs.hp.value = data.hp;
    this.refs.attack.value = data.attack;
    this.refs.deffense.value = data.deffense;
    this.refs.pokemonType.value = data.pokemonType;

    this.setState({
      act: 1,
      index: i
    });

    this.refs.name.focus();
  }  

  render() {
    let datas = this.state.datas;
    return (
      <div className="App">
        <h2>{this.state.title}</h2>
        <form ref="myForm" className="myForm">
          <input type="text" ref="name" placeholder="your Pokemon Name" className="formField" />
          <input type="text" ref="details" placeholder="your details" className="formField" />
          <input type="text" ref="hp" placeholder="your hp" className="formField" />
          <input type="text" ref="attack" placeholder="your attack" className="formField" />
          <input type="text" ref="deffense" placeholder="your deffense" className="formField" />
          <input type="text" ref="pokemonType" placeholder="your Pokemon Type" className="formField" />
          <button onClick={(e)=>this.fSubmit(e)} className="myButton">submit </button>
        </form>
        <pre>
          {datas.map((data, i) =>
            <li key={i} className="myList">
              {i+1}. {data.name}, details:{data.details},hp: {data.hp}, attack:{data.attack}, deffense:{data.deffense}, Type:{data.pokemonType}
              <button onClick={()=>this.fRemove(i)} className="myListButton">remove </button>
              <button onClick={()=>this.fEdit(i)} className="myListButton">edit </button>
            </li>
          )}
        </pre>
      </div>
    );
  }
}

export default App;
